# Transfer Learning-Based Classification of Poultry Diseases

This project uses transfer learning to classify poultry diseases into four categories:
- Salmonella
- New Castle Disease
- Coccidiosis
- Healthy

Includes Flask API and simple web frontend.
